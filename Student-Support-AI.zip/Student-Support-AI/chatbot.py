from typing import Dict, Any, List, Optional
import random


class SupportiveChatbot:
    def __init__(self):
        self.greetings = [
            "Hi there! I'm here to listen and support you. How are you feeling today?",
            "Hello! I'm glad you're here. How are things going for you?",
            "Welcome! I'm here to chat whenever you need. How can I support you today?"
        ]
        
        self.acknowledgments = [
            "I hear you. That sounds really tough.",
            "Thank you for sharing that with me.",
            "It takes courage to talk about how you're feeling.",
            "I'm here for you. Your feelings are valid.",
            "That sounds really challenging. I appreciate you opening up."
        ]
        
        self.encouragements = [
            "You're doing your best, and that matters.",
            "It's okay to not be okay sometimes.",
            "You're stronger than you know.",
            "Taking one step at a time is still progress.",
            "You've gotten through difficult times before, and you can again.",
            "It's okay to ask for help. That's a sign of strength, not weakness."
        ]
        
        self.breathing_exercises = [
            {
                "name": "4-7-8 Breathing",
                "description": "Let's try a calming breath together:\n1. Breathe in slowly through your nose for 4 seconds\n2. Hold your breath gently for 7 seconds\n3. Exhale slowly through your mouth for 8 seconds\n4. Repeat 3-4 times\n\nHow do you feel?"
            },
            {
                "name": "Box Breathing",
                "description": "Try this box breathing technique:\n1. Breathe in for 4 seconds\n2. Hold for 4 seconds\n3. Breathe out for 4 seconds\n4. Hold for 4 seconds\n5. Repeat the square\n\nThis can help calm your nervous system."
            },
            {
                "name": "Simple Deep Breath",
                "description": "Let's take a slow breath together:\n- Breathe in deeply through your nose... feel your belly expand\n- Hold for a moment\n- Now slowly breathe out through your mouth\n\nTake your time. There's no rush."
            }
        ]
        
        self.grounding_exercises = [
            {
                "name": "5-4-3-2-1 Grounding",
                "description": "Let's ground yourself in the present moment:\n- Name 5 things you can SEE\n- Name 4 things you can TOUCH\n- Name 3 things you can HEAR\n- Name 2 things you can SMELL\n- Name 1 thing you can TASTE\n\nThis helps bring you back to the here and now."
            },
            {
                "name": "Body Scan",
                "description": "Try this quick body scan:\n- Start at your feet and notice how they feel\n- Slowly move your attention up through your legs, body, arms, and head\n- Notice any tension and imagine breathing into those areas\n- Let go of what you can\n\nTake your time with this."
            },
            {
                "name": "Safe Place Visualization",
                "description": "Close your eyes and imagine a place where you feel completely safe and calm:\n- What does it look like?\n- What sounds do you hear there?\n- How does it feel to be there?\n\nYou can visit this place in your mind whenever you need a moment of peace."
            }
        ]
        
        self.coping_tips = [
            "Sometimes a short walk or some movement can help shift your mood.",
            "Writing down your thoughts in a journal can help process difficult feelings.",
            "Listening to music you love can be a great way to feel better.",
            "Reaching out to a friend or trusted person can lighten the load.",
            "Taking a break from screens and social media can help reduce stress.",
            "Doing something creative like drawing or playing music can be therapeutic.",
            "Getting enough sleep is really important for how we feel.",
            "Drinking water and eating regular meals helps our body and mind."
        ]
        
        self.emotion_responses = {
            "sadness": [
                "I'm sorry you're feeling sad. It's okay to feel this way.",
                "Sadness is a natural emotion. Would you like to talk more about what's making you feel this way?",
                "I hear that you're going through a hard time. I'm here to listen."
            ],
            "anxiety": [
                "Anxiety can feel overwhelming. Let's try to take it one moment at a time.",
                "It sounds like you're feeling anxious. Would a breathing exercise help right now?",
                "I understand anxiety can be really tough. You're not alone in this."
            ],
            "anger": [
                "It sounds like you're feeling frustrated or angry. Those are valid feelings.",
                "Anger often tells us something important. What do you think is underneath it?",
                "It's okay to feel angry. Let's find a healthy way to work through it."
            ],
            "exhaustion": [
                "It sounds like you're feeling really drained. That's understandable.",
                "Being exhausted is hard. What's one small thing you could do to take care of yourself today?",
                "When we're burnt out, even small steps matter. Be gentle with yourself."
            ],
            "confusion": [
                "Feeling confused or lost is really common. What's on your mind?",
                "It's okay not to have all the answers. Let's talk through it together.",
                "Sometimes things feel unclear. I'm here to help you sort through your thoughts."
            ],
            "hope": [
                "I'm glad to hear some hopefulness in what you're saying!",
                "It sounds like you're finding some strength. That's wonderful.",
                "Holding onto hope, even a little bit, is so important."
            ]
        }
        
        self.closings = [
            "Remember, I'm always here if you need to talk.",
            "Take care of yourself. You matter.",
            "Don't forget - it's okay to reach out for help when you need it.",
            "You're not alone in this. There are people who care about you."
        ]
    
    def get_greeting(self) -> str:
        return random.choice(self.greetings)
    
    def generate_response(self, analysis: Dict[str, Any]) -> Dict[str, Any]:
        aggregated = analysis.get("aggregated_analysis", {})
        
        if aggregated.get("is_crisis"):
            return {
                "type": "crisis",
                "message": None,
                "requires_safety_response": True
            }
        
        response_parts = []
        suggested_techniques = []
        
        response_parts.append(random.choice(self.acknowledgments))
        
        risk_level = aggregated.get("risk_level", "minimal")
        needs_support = aggregated.get("needs_support", False)
        
        primary_emotion = self._get_primary_emotion(analysis)
        if primary_emotion and primary_emotion in self.emotion_responses:
            response_parts.append(random.choice(self.emotion_responses[primary_emotion]))
        
        if risk_level in ["medium", "high"] or needs_support:
            response_parts.append(random.choice(self.encouragements))
            
            if random.random() > 0.5:
                breathing = random.choice(self.breathing_exercises)
                suggested_techniques.append({
                    "type": "breathing",
                    "technique": breathing
                })
                response_parts.append(f"\nHere's something that might help:\n\n**{breathing['name']}**\n{breathing['description']}")
            else:
                grounding = random.choice(self.grounding_exercises)
                suggested_techniques.append({
                    "type": "grounding",
                    "technique": grounding
                })
                response_parts.append(f"\nHere's a grounding exercise you can try:\n\n**{grounding['name']}**\n{grounding['description']}")
        else:
            response_parts.append(random.choice(self.coping_tips))
        
        response_parts.append("\n" + random.choice(self.closings))
        
        full_message = "\n\n".join(response_parts)
        
        return {
            "type": "supportive",
            "message": full_message,
            "suggested_techniques": suggested_techniques,
            "risk_level": risk_level,
            "requires_safety_response": False
        }
    
    def _get_primary_emotion(self, analysis: Dict[str, Any]) -> Optional[str]:
        for node_result in analysis.get("node_results", []):
            if node_result.get("node_name") == "Emotion Detector":
                data = node_result.get("data", {})
                return data.get("primary_emotion")
        return None
    
    def get_technique(self, technique_type: str) -> Dict[str, Any]:
        if technique_type == "breathing":
            return random.choice(self.breathing_exercises)
        elif technique_type == "grounding":
            return random.choice(self.grounding_exercises)
        else:
            return {"name": "Coping Tip", "description": random.choice(self.coping_tips)}
