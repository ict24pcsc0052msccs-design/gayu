import os
from flask import Flask, render_template, request, jsonify, session
from datetime import datetime
from mesh import MultiBrainMesh
from safety import SafetyLayer
from chatbot import SupportiveChatbot
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev-secret-key-change-in-production")

mesh = MultiBrainMesh()
safety = SafetyLayer()
chatbot = SupportiveChatbot()

conversation_logs = []


@app.route("/")
def index():
    return render_template("index.html", disclaimer=safety.get_disclaimer())


@app.route("/api/chat", methods=["POST"])
def chat():
    data = request.get_json()
    message = data.get("message", "").strip()
    
    if not message:
        return jsonify({"error": "Message cannot be empty"}), 400
    
    log_entry = {
        "timestamp": datetime.now().isoformat(),
        "user_message": message,
        "analysis": None,
        "response": None,
        "mode": None
    }
    
    safety_check = safety.check_message(message)
    
    if not safety_check["allow_normal_response"]:
        crisis_response = safety_check["crisis_response"]
        log_entry["mode"] = "crisis"
        log_entry["response"] = crisis_response["message"]
        log_entry["analysis"] = {"safety_check": safety_check}
        conversation_logs.append(log_entry)
        
        return jsonify({
            "response": crisis_response["message"],
            "mode": "crisis",
            "safety_status": safety_check["safety_status"],
            "hotlines": crisis_response["hotlines"],
            "node_analysis": None,
            "show_crisis_resources": True
        })
    
    mesh_analysis = mesh.analyze_message(message)
    
    if mesh_analysis.get("status") == "mesh_degraded":
        log_entry["mode"] = "degraded"
        log_entry["analysis"] = mesh_analysis
        conversation_logs.append(log_entry)
        
        return jsonify({
            "response": "I'm having some technical difficulties right now. If you need support, please reach out to a trusted adult or counselor.",
            "mode": "degraded",
            "mesh_status": mesh.get_mesh_status(),
            "show_crisis_resources": True
        })
    
    aggregated = mesh_analysis.get("aggregated_analysis", {})
    if aggregated.get("is_crisis"):
        crisis_response = safety._get_crisis_response("high")
        log_entry["mode"] = "crisis"
        log_entry["response"] = crisis_response["message"]
        log_entry["analysis"] = mesh_analysis
        conversation_logs.append(log_entry)
        
        return jsonify({
            "response": crisis_response["message"],
            "mode": "crisis",
            "safety_status": "HIGH_RISK",
            "hotlines": crisis_response["hotlines"],
            "node_analysis": format_node_analysis(mesh_analysis),
            "show_crisis_resources": True
        })
    
    chatbot_response = chatbot.generate_response(mesh_analysis)
    
    log_entry["mode"] = "support"
    log_entry["response"] = chatbot_response["message"]
    log_entry["analysis"] = mesh_analysis
    conversation_logs.append(log_entry)
    
    return jsonify({
        "response": chatbot_response["message"],
        "mode": "support",
        "risk_level": chatbot_response["risk_level"],
        "node_analysis": format_node_analysis(mesh_analysis),
        "suggested_techniques": chatbot_response.get("suggested_techniques", []),
        "show_crisis_resources": False
    })


def format_node_analysis(mesh_analysis: dict) -> list:
    formatted = []
    for result in mesh_analysis.get("node_results", []):
        node_info = {
            "name": result.get("node_name"),
            "status": result.get("status"),
            "is_healthy": result.get("is_healthy")
        }
        
        if result.get("data"):
            data = result["data"]
            node_info["risk_contribution"] = data.get("risk_contribution", 0)
            node_info["needs_support"] = data.get("needs_support", False)
            
            if "sentiment_label" in data:
                node_info["details"] = f"Sentiment: {data['sentiment_label']} (polarity: {data['polarity']})"
            elif "primary_emotion" in data:
                node_info["details"] = f"Primary emotion: {data['primary_emotion'] or 'neutral'}"
            elif "risk_level" in data:
                node_info["details"] = f"Risk level: {data['risk_level']}"
            elif "toxicity_score" in data:
                node_info["details"] = f"Toxicity score: {data['toxicity_score']}"
            elif "urgency_level" in data:
                node_info["details"] = f"Urgency: {data['urgency_level']}, Help-seeking: {data['is_seeking_help']}"
        
        formatted.append(node_info)
    
    return formatted


@app.route("/api/mesh/status", methods=["GET"])
def mesh_status():
    return jsonify(mesh.get_mesh_status())


@app.route("/api/mesh/reset", methods=["POST"])
def reset_mesh():
    result = mesh.reset_failed_nodes()
    return jsonify(result)


@app.route("/api/technique/<technique_type>", methods=["GET"])
def get_technique(technique_type):
    technique = chatbot.get_technique(technique_type)
    return jsonify(technique)


@app.route("/api/greeting", methods=["GET"])
def get_greeting():
    return jsonify({"greeting": chatbot.get_greeting()})


@app.route("/api/logs", methods=["GET"])
def get_logs():
    return jsonify({
        "logs": conversation_logs[-50:],
        "total_conversations": len(conversation_logs)
    })


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
