from typing import Dict, Any, List
from nodes import SentimentNode, EmotionNode, KeywordRiskNode, ToxicityNode, ContextNode
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class MultiBrainMesh:
    def __init__(self):
        self.nodes = [
            SentimentNode(),
            EmotionNode(),
            KeywordRiskNode(),
            ToxicityNode(),
            ContextNode()
        ]
        self.min_healthy_nodes = 2
    
    def get_mesh_status(self) -> Dict[str, Any]:
        healthy_count = sum(1 for node in self.nodes if node.is_healthy)
        return {
            "total_nodes": len(self.nodes),
            "healthy_nodes": healthy_count,
            "unhealthy_nodes": len(self.nodes) - healthy_count,
            "mesh_operational": healthy_count >= self.min_healthy_nodes,
            "node_statuses": [node.get_health_status() for node in self.nodes]
        }
    
    def analyze_message(self, message: str) -> Dict[str, Any]:
        node_results = []
        successful_analyses = []
        failed_analyses = []
        
        for node in self.nodes:
            result = node.safe_analyze(message)
            node_results.append(result)
            
            if result["status"] == "success":
                successful_analyses.append(result)
            else:
                failed_analyses.append(result)
                logger.warning(f"Node {node.name} failed: {result.get('error')}")
        
        if len(successful_analyses) < self.min_healthy_nodes:
            return {
                "status": "mesh_degraded",
                "message": "Too many nodes failed - mesh cannot provide reliable analysis",
                "node_results": node_results,
                "is_crisis": True,
                "recommendation": "Please seek help from a trusted adult or counselor"
            }
        
        aggregated = self._aggregate_results(successful_analyses)
        
        return {
            "status": "success",
            "node_results": node_results,
            "aggregated_analysis": aggregated,
            "mesh_health": {
                "successful_nodes": len(successful_analyses),
                "failed_nodes": len(failed_analyses),
                "self_healed": len(failed_analyses) > 0 and len(successful_analyses) >= self.min_healthy_nodes
            }
        }
    
    def _aggregate_results(self, successful_analyses: List[Dict]) -> Dict[str, Any]:
        is_crisis = False
        total_risk = 0.0
        needs_support = False
        crisis_indicators = []
        
        node_votes = []
        
        for result in successful_analyses:
            data = result.get("data", {})
            node_name = result.get("node_name", "Unknown")
            
            if data:
                risk = data.get("risk_contribution", 0)
                total_risk += risk
                
                if data.get("is_crisis", False):
                    is_crisis = True
                    crisis_indicators.append(node_name)
                
                if data.get("needs_support", False):
                    needs_support = True
                
                vote = {
                    "node": node_name,
                    "risk_contribution": risk,
                    "flagged_crisis": data.get("is_crisis", False),
                    "needs_support": data.get("needs_support", False)
                }
                node_votes.append(vote)
        
        avg_risk = total_risk / len(successful_analyses) if successful_analyses else 0
        
        if avg_risk > 0.7:
            risk_level = "high"
        elif avg_risk > 0.4:
            risk_level = "medium"
        elif avg_risk > 0.2:
            risk_level = "low"
        else:
            risk_level = "minimal"
        
        support_votes = sum(1 for v in node_votes if v["needs_support"])
        consensus_needs_support = support_votes > len(node_votes) / 2
        
        return {
            "is_crisis": is_crisis,
            "crisis_flagged_by": crisis_indicators,
            "average_risk_score": round(avg_risk, 2),
            "risk_level": risk_level,
            "needs_support": needs_support or consensus_needs_support,
            "node_votes": node_votes,
            "consensus": {
                "support_votes": support_votes,
                "total_votes": len(node_votes),
                "consensus_reached": consensus_needs_support
            }
        }
    
    def reset_failed_nodes(self) -> Dict[str, Any]:
        reset_nodes = []
        for node in self.nodes:
            if not node.is_healthy:
                node.is_healthy = True
                node.last_error = None
                reset_nodes.append(node.name)
        
        return {
            "reset_count": len(reset_nodes),
            "reset_nodes": reset_nodes,
            "mesh_status": self.get_mesh_status()
        }
