from abc import ABC, abstractmethod
from typing import Dict, Any
import traceback


class BaseNode(ABC):
    def __init__(self, name: str):
        self.name = name
        self.is_healthy = True
        self.last_error = None
    
    @abstractmethod
    def analyze(self, message: str) -> Dict[str, Any]:
        pass
    
    def safe_analyze(self, message: str) -> Dict[str, Any]:
        try:
            result = self.analyze(message)
            self.is_healthy = True
            self.last_error = None
            return {
                "node_name": self.name,
                "status": "success",
                "is_healthy": True,
                "data": result
            }
        except Exception as e:
            self.is_healthy = False
            self.last_error = str(e)
            return {
                "node_name": self.name,
                "status": "failed",
                "is_healthy": False,
                "error": str(e),
                "data": None
            }
    
    def get_health_status(self) -> Dict[str, Any]:
        return {
            "node_name": self.name,
            "is_healthy": self.is_healthy,
            "last_error": self.last_error
        }
