from nodes.base_node import BaseNode
from typing import Dict, Any, List
import re


class ContextNode(BaseNode):
    def __init__(self):
        super().__init__("Context Analyzer")
        
        self.urgency_patterns = [
            r"\b(right now|immediately|urgent|can't wait|need help now)\b",
            r"\b(tonight|today|this moment|as we speak)\b",
            r"\b(about to|going to|planning to|decided to)\b"
        ]
        
        self.help_seeking_patterns = [
            r"\b(help me|need help|please help|someone help)\b",
            r"\b(what should i do|what can i do|how do i)\b",
            r"\b(talk to someone|need someone|reach out)\b",
            r"\b(advice|guidance|support)\b"
        ]
        
        self.positive_coping_patterns = [
            r"\b(trying to|working on|getting better|making progress)\b",
            r"\b(talked to|speaking with|seeing a|going to therapy)\b",
            r"\b(coping|managing|handling|dealing with)\b",
            r"\b(grateful|thankful|appreciate|hopeful)\b"
        ]
        
        self.temporal_patterns = [
            r"\b(always|forever|never|constantly|every day|all the time)\b",
            r"\b(for weeks|for months|for years|long time)\b",
            r"\b(recently|lately|these days|this week)\b"
        ]
    
    def analyze(self, message: str) -> Dict[str, Any]:
        message_lower = message.lower()
        
        urgency_matches = []
        for pattern in self.urgency_patterns:
            found = re.findall(pattern, message_lower)
            urgency_matches.extend(found)
        
        help_seeking_matches = []
        for pattern in self.help_seeking_patterns:
            found = re.findall(pattern, message_lower)
            help_seeking_matches.extend(found)
        
        positive_coping_matches = []
        for pattern in self.positive_coping_patterns:
            found = re.findall(pattern, message_lower)
            positive_coping_matches.extend(found)
        
        temporal_matches = []
        for pattern in self.temporal_patterns:
            found = re.findall(pattern, message_lower)
            temporal_matches.extend(found)
        
        urgency_score = min(len(urgency_matches) * 0.3, 1.0)
        is_seeking_help = len(help_seeking_matches) > 0
        is_coping_positively = len(positive_coping_matches) > 0
        has_chronic_language = any(word in message_lower for word in 
            ["always", "forever", "never", "for years", "for months"])
        
        message_length = len(message.split())
        is_brief = message_length < 5
        is_detailed = message_length > 30
        
        has_questions = "?" in message
        
        if urgency_score > 0.5 and not is_coping_positively:
            risk_contribution = 0.7
        elif has_chronic_language and not is_coping_positively:
            risk_contribution = 0.4
        elif is_seeking_help:
            risk_contribution = 0.2
        else:
            risk_contribution = 0.1
        
        if is_coping_positively:
            risk_contribution = max(0, risk_contribution - 0.3)
        
        return {
            "urgency_level": round(urgency_score, 2),
            "is_seeking_help": is_seeking_help,
            "is_coping_positively": is_coping_positively,
            "has_chronic_language": has_chronic_language,
            "message_characteristics": {
                "length": message_length,
                "is_brief": is_brief,
                "is_detailed": is_detailed,
                "has_questions": has_questions
            },
            "context_indicators": {
                "urgency": list(set(urgency_matches))[:3],
                "help_seeking": list(set(help_seeking_matches))[:3],
                "positive_coping": list(set(positive_coping_matches))[:3],
                "temporal": list(set(temporal_matches))[:3]
            },
            "risk_contribution": round(risk_contribution, 2),
            "needs_support": urgency_score > 0.3 or is_seeking_help
        }
