from nodes.base_node import BaseNode
from typing import Dict, Any
import re


class EmotionNode(BaseNode):
    def __init__(self):
        super().__init__("Emotion Detector")
        self.emotion_patterns = {
            "sadness": [
                r"\b(sad|unhappy|depressed|down|blue|miserable|hopeless|empty|lonely|alone)\b",
                r"\b(crying|tears|cry|sobbing|weeping)\b",
                r"\b(heartbroken|devastated|grief|mourning|loss)\b"
            ],
            "anxiety": [
                r"\b(anxious|worried|nervous|stressed|overwhelmed|panicked|panic)\b",
                r"\b(fear|scared|afraid|terrified|frightened)\b",
                r"\b(can't breathe|heart racing|shaking|trembling)\b"
            ],
            "anger": [
                r"\b(angry|mad|furious|annoyed|frustrated|irritated|enraged)\b",
                r"\b(hate|hatred|rage|resent|resentment)\b"
            ],
            "confusion": [
                r"\b(confused|lost|don't know|uncertain|unsure|bewildered)\b",
                r"\b(what should i do|help me understand|i don't get it)\b"
            ],
            "exhaustion": [
                r"\b(tired|exhausted|drained|burnt out|burnout|fatigue|worn out)\b",
                r"\b(can't anymore|give up|too much|overwhelming)\b"
            ],
            "hope": [
                r"\b(hope|hopeful|better|improving|positive|optimistic)\b",
                r"\b(getting through|making it|surviving|coping)\b"
            ]
        }
    
    def analyze(self, message: str) -> Dict[str, Any]:
        message_lower = message.lower()
        detected_emotions = {}
        
        for emotion, patterns in self.emotion_patterns.items():
            score = 0
            matches = []
            for pattern in patterns:
                found = re.findall(pattern, message_lower)
                if found:
                    score += len(found) * 0.3
                    matches.extend(found)
            if score > 0:
                detected_emotions[emotion] = {
                    "score": min(score, 1.0),
                    "indicators": list(set(matches))[:5]
                }
        
        primary_emotion = None
        max_score = 0
        for emotion, data in detected_emotions.items():
            if data["score"] > max_score:
                max_score = data["score"]
                primary_emotion = emotion
        
        negative_emotions = ["sadness", "anxiety", "anger", "exhaustion", "confusion"]
        risk_contribution = 0.0
        for emotion in negative_emotions:
            if emotion in detected_emotions:
                risk_contribution += detected_emotions[emotion]["score"] * 0.2
        
        return {
            "detected_emotions": detected_emotions,
            "primary_emotion": primary_emotion,
            "emotional_intensity": round(max_score, 2),
            "risk_contribution": round(min(risk_contribution, 1.0), 2),
            "needs_support": primary_emotion in negative_emotions
        }
