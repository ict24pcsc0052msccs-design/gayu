from nodes.base_node import BaseNode
from typing import Dict, Any, List
import re


class KeywordRiskNode(BaseNode):
    def __init__(self):
        super().__init__("Keyword Risk Scanner")
        
        self.high_risk_patterns = [
            r"\b(kill myself|end my life|end it all|take my life)\b",
            r"\b(want to die|wanna die|wish i was dead|better off dead)\b",
            r"\b(hurt myself|harm myself|cutting myself|self.?harm)\b",
            r"\b(suicide|suicidal)\b",
            r"\b(no reason to live|nothing to live for|no point in living)\b",
            r"\b(want to disappear|disappear forever)\b",
            r"\b(goodbye forever|final goodbye|this is goodbye)\b",
            r"\b(can't go on|can't take it anymore|can't do this anymore)\b",
            r"\b(everyone would be better without me|burden to everyone)\b",
            r"\b(planning to end|made a plan|have a plan to)\b"
        ]
        
        self.medium_risk_patterns = [
            r"\b(hopeless|no hope|lost all hope)\b",
            r"\b(worthless|i'm nothing|i'm useless)\b",
            r"\b(nobody cares|no one cares|nobody loves me)\b",
            r"\b(can't cope|falling apart|breaking down)\b",
            r"\b(trapped|no way out|stuck forever)\b",
            r"\b(hate myself|hate my life|hate everything)\b",
            r"\b(give up|giving up|ready to quit)\b",
            r"\b(empty inside|feel nothing|numb)\b"
        ]
        
        self.low_risk_patterns = [
            r"\b(stressed|stressed out|so stressed)\b",
            r"\b(overwhelmed|too much pressure)\b",
            r"\b(anxious|anxiety|worried)\b",
            r"\b(sad|feeling down|not okay)\b",
            r"\b(struggling|having a hard time)\b",
            r"\b(scared|afraid|fear)\b"
        ]
    
    def _check_patterns(self, message: str, patterns: List[str]) -> List[str]:
        matches = []
        for pattern in patterns:
            found = re.findall(pattern, message, re.IGNORECASE)
            matches.extend(found)
        return list(set(matches))
    
    def analyze(self, message: str) -> Dict[str, Any]:
        message_lower = message.lower()
        
        high_matches = self._check_patterns(message_lower, self.high_risk_patterns)
        medium_matches = self._check_patterns(message_lower, self.medium_risk_patterns)
        low_matches = self._check_patterns(message_lower, self.low_risk_patterns)
        
        if high_matches:
            risk_level = "high"
            risk_score = 1.0
            is_crisis = True
        elif medium_matches:
            risk_level = "medium"
            risk_score = 0.6
            is_crisis = False
        elif low_matches:
            risk_level = "low"
            risk_score = 0.3
            is_crisis = False
        else:
            risk_level = "none"
            risk_score = 0.0
            is_crisis = False
        
        return {
            "risk_level": risk_level,
            "risk_score": round(risk_score, 2),
            "is_crisis": is_crisis,
            "high_risk_matches": high_matches,
            "medium_risk_matches": medium_matches,
            "low_risk_matches": low_matches,
            "risk_contribution": round(risk_score, 2),
            "needs_support": risk_level != "none"
        }
