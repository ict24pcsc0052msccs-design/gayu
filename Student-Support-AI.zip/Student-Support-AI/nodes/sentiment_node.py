from nodes.base_node import BaseNode
from textblob import TextBlob
from typing import Dict, Any


class SentimentNode(BaseNode):
    def __init__(self):
        super().__init__("Sentiment Analyzer")
    
    def analyze(self, message: str) -> Dict[str, Any]:
        blob = TextBlob(message)
        polarity = blob.sentiment.polarity
        subjectivity = blob.sentiment.subjectivity
        
        if polarity < -0.5:
            sentiment_label = "very_negative"
            risk_level = 0.8
        elif polarity < -0.2:
            sentiment_label = "negative"
            risk_level = 0.5
        elif polarity < 0.2:
            sentiment_label = "neutral"
            risk_level = 0.2
        elif polarity < 0.5:
            sentiment_label = "positive"
            risk_level = 0.1
        else:
            sentiment_label = "very_positive"
            risk_level = 0.0
        
        return {
            "polarity": round(polarity, 3),
            "subjectivity": round(subjectivity, 3),
            "sentiment_label": sentiment_label,
            "risk_contribution": round(risk_level, 2),
            "needs_support": polarity < -0.2
        }
