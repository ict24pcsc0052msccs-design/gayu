from nodes.base_node import BaseNode
from typing import Dict, Any
import re


class ToxicityNode(BaseNode):
    def __init__(self):
        super().__init__("Toxicity & Harm Detector")
        
        self.self_directed_harm = [
            r"\b(hate myself|i'm worthless|i'm a failure|i'm garbage)\b",
            r"\b(i deserve to suffer|i deserve pain|punish myself)\b",
            r"\b(ugly|disgusting|pathetic)\b.{0,20}\b(me|myself|i am)\b",
            r"\b(i am|i'm)\b.{0,10}\b(ugly|disgusting|pathetic|useless)\b"
        ]
        
        self.harmful_intent_patterns = [
            r"\b(hurt|harm|punish|destroy)\b.{0,15}\b(myself|me)\b",
            r"\b(don't deserve)\b.{0,15}\b(love|happiness|life|help|to live)\b",
            r"\b(should just)\b.{0,10}\b(die|disappear|give up)\b"
        ]
        
        self.isolation_patterns = [
            r"\b(all alone|completely alone|no friends|nobody)\b",
            r"\b(no one understands|nobody gets it|alone in this)\b",
            r"\b(pushed everyone away|everyone left|abandoned)\b"
        ]
    
    def analyze(self, message: str) -> Dict[str, Any]:
        message_lower = message.lower()
        
        self_harm_indicators = []
        for pattern in self.self_directed_harm:
            found = re.findall(pattern, message_lower)
            self_harm_indicators.extend([str(f) for f in found])
        
        harmful_intent = []
        for pattern in self.harmful_intent_patterns:
            found = re.findall(pattern, message_lower)
            harmful_intent.extend([str(f) for f in found])
        
        isolation_indicators = []
        for pattern in self.isolation_patterns:
            found = re.findall(pattern, message_lower)
            isolation_indicators.extend([str(f) for f in found])
        
        has_self_harm = len(self_harm_indicators) > 0
        has_harmful_intent = len(harmful_intent) > 0
        has_isolation = len(isolation_indicators) > 0
        
        toxicity_score = 0.0
        if has_self_harm:
            toxicity_score += 0.4
        if has_harmful_intent:
            toxicity_score += 0.5
        if has_isolation:
            toxicity_score += 0.2
        
        toxicity_score = min(toxicity_score, 1.0)
        
        is_crisis = has_harmful_intent or (has_self_harm and has_isolation)
        
        return {
            "toxicity_score": round(toxicity_score, 2),
            "has_self_directed_negativity": has_self_harm,
            "has_harmful_intent": has_harmful_intent,
            "has_isolation_language": has_isolation,
            "is_crisis": is_crisis,
            "indicators": {
                "self_harm": self_harm_indicators[:3],
                "harmful_intent": harmful_intent[:3],
                "isolation": isolation_indicators[:3]
            },
            "risk_contribution": round(toxicity_score, 2),
            "needs_support": toxicity_score > 0.2
        }
