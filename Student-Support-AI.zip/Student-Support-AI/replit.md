# AI Student Support System

## Overview
A safe, ethical AI system using a "self-healing multibrain neural mesh" combined with a supportive mental-health chatbot for students. The system detects emotional distress, offers supportive messages, teaches stress-relief techniques, and alerts users to seek human help when high-risk language appears.

## Project Structure
```
├── main.py              # Flask application entry point
├── mesh.py              # Multibrain mesh controller with self-healing
├── safety.py            # Crisis detection and safety layer
├── chatbot.py           # Supportive response generator
├── nodes/               # AI brain nodes directory
│   ├── __init__.py
│   ├── base_node.py     # Abstract base class for nodes
│   ├── sentiment_node.py    # Sentiment analysis (TextBlob)
│   ├── emotion_node.py      # Emotion detection patterns
│   ├── keyword_risk_node.py # Risk keyword scanning
│   ├── toxicity_node.py     # Self-harm/toxicity detection
│   └── context_node.py      # Context and urgency analysis
├── templates/
│   └── index.html       # Chat interface
├── static/
│   ├── style.css        # Styling
│   └── script.js        # Frontend logic
└── attached_assets/     # Project requirements document
```

## Architecture

### Multibrain Neural Mesh
- 5 specialized AI "brain nodes" analyze messages from different perspectives
- Self-healing: if one node fails, remaining nodes continue analysis
- Voting/consensus mechanism for risk assessment
- Each node contributes a risk score (0-1)

### Safety System
- Two-tier detection: immediate crisis and high-risk phrases
- Automatic crisis mode activation stops normal conversation
- Immediate display of crisis hotlines and counselor referral
- No harmful content or self-harm instructions

### Chatbot Features
- Supportive acknowledgments and encouragement
- Breathing exercises (4-7-8, Box, Simple Deep Breath)
- Grounding techniques (5-4-3-2-1, Body Scan, Safe Place)
- Emotion-specific responses
- Coping tips and healthy strategies

## Running the Project
```bash
python main.py
```
Server runs on port 5000.

## API Endpoints
- `GET /` - Main chat interface
- `POST /api/chat` - Send message, receive analysis and response
- `GET /api/mesh/status` - Check mesh health
- `POST /api/mesh/reset` - Reset failed nodes
- `GET /api/technique/<type>` - Get breathing/grounding exercise
- `GET /api/greeting` - Get initial greeting
- `GET /api/logs` - View conversation logs

## Safety Guidelines
- Never provides instructions about self-harm
- Redirects to human help when danger detected
- All advice is general, positive, and age-appropriate
- Clear disclaimers about not being a real therapist

## Dependencies
- Flask (web framework)
- TextBlob (sentiment analysis)
