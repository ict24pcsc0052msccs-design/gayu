from typing import Dict, Any, List
import re


class SafetyLayer:
    def __init__(self):
        self.crisis_hotlines = {
            "US": "988 (Suicide & Crisis Lifeline)",
            "UK": "116 123 (Samaritans)",
            "Canada": "1-833-456-4566 (Crisis Services Canada)",
            "Australia": "13 11 14 (Lifeline)",
            "International": "findahelpline.com"
        }
        
        self.immediate_crisis_phrases = [
            r"i('m| am) going to kill myself",
            r"i('m| am) going to end (my life|it all|it)",
            r"i have a plan to (die|kill|end)",
            r"tonight i('m| am| will) (going to )?(die|end it|kill myself)",
            r"this is (my )?goodbye",
            r"i('ve| have) decided to (die|end|kill)",
            r"i('m| am) about to (hurt|harm|kill) myself",
            r"i (want|need) to die( right now)?",
            r"i('m| am) (going to|gonna) hurt myself"
        ]
        
        self.high_risk_phrases = [
            r"want to (die|disappear|end it)",
            r"wish i (was|were) dead",
            r"better off (dead|without me)",
            r"no (reason|point) (to|in) liv(e|ing)",
            r"can't (go on|take it|do this) anymore",
            r"(hurt|harm|cut) myself",
            r"suicid(e|al)",
            r"kill myself",
            r"end my life",
            r"nobody would (miss|care)",
            r"world would be better without me"
        ]
    
    def check_message(self, message: str) -> Dict[str, Any]:
        message_lower = message.lower().strip()
        
        immediate_crisis = self._check_patterns(message_lower, self.immediate_crisis_phrases)
        if immediate_crisis:
            return {
                "safety_status": "IMMEDIATE_CRISIS",
                "severity": "critical",
                "matched_patterns": immediate_crisis,
                "requires_intervention": True,
                "allow_normal_response": False,
                "crisis_response": self._get_crisis_response("immediate")
            }
        
        high_risk = self._check_patterns(message_lower, self.high_risk_phrases)
        if high_risk:
            return {
                "safety_status": "HIGH_RISK",
                "severity": "high",
                "matched_patterns": high_risk,
                "requires_intervention": True,
                "allow_normal_response": False,
                "crisis_response": self._get_crisis_response("high")
            }
        
        return {
            "safety_status": "SAFE",
            "severity": "none",
            "matched_patterns": [],
            "requires_intervention": False,
            "allow_normal_response": True,
            "crisis_response": None
        }
    
    def _check_patterns(self, message: str, patterns: List[str]) -> List[str]:
        matches = []
        for pattern in patterns:
            if re.search(pattern, message):
                matches.append(pattern)
        return matches
    
    def _get_crisis_response(self, severity: str) -> Dict[str, Any]:
        if severity == "immediate":
            message = """Thank you for telling me. I hear you, and I'm really glad you reached out.

What you're going through sounds incredibly difficult, and you deserve real support right now.

Please reach out to someone who can help immediately:
- Talk to a trusted adult, parent, teacher, or counselor
- Call a crisis helpline (they're free and confidential):
  * US: 988 (Suicide & Crisis Lifeline)
  * UK: 116 123 (Samaritans)
  * Canada: 1-833-456-4566
  * Australia: 13 11 14 (Lifeline)
  * Or visit findahelpline.com

You matter. Your feelings are valid. Please stay safe and reach out to someone who can help you through this."""
        else:
            message = """Thank you for sharing how you feel. That took courage.

I can hear that you're going through something really tough right now. You're not alone in this.

I want to make sure you have the support you need. Please consider:
- Talking to a trusted adult, teacher, parent, or school counselor
- Reaching out to a crisis helpline if you need immediate support:
  * US: 988 (Suicide & Crisis Lifeline)
  * UK: 116 123 (Samaritans)  
  * Canada: 1-833-456-4566
  * Australia: 13 11 14 (Lifeline)
  * Or visit findahelpline.com

You deserve care and support. Please reach out to someone you trust."""
        
        return {
            "message": message,
            "hotlines": self.crisis_hotlines,
            "action_required": "REDIRECT_TO_HUMAN_HELP"
        }
    
    def get_disclaimer(self) -> str:
        return """IMPORTANT DISCLAIMER:
This chatbot is NOT a therapist or mental health professional. It cannot diagnose, treat, or provide medical advice.

If you are feeling unsafe or in crisis, please:
- Talk to a trusted adult immediately
- Call a crisis helpline
- Go to your nearest emergency room

This tool is for emotional support only and does not replace professional help."""
