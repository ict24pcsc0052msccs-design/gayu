document.addEventListener('DOMContentLoaded', function() {
    const chatForm = document.getElementById('chatForm');
    const messageInput = document.getElementById('messageInput');
    const chatMessages = document.getElementById('chatMessages');
    const sendButton = document.getElementById('sendButton');
    const nodeList = document.getElementById('nodeList');
    const modeIndicator = document.getElementById('modeIndicator');
    const crisisResources = document.getElementById('crisisResources');
    const meshStatus = document.getElementById('meshStatus');

    chatForm.addEventListener('submit', handleSubmit);
    messageInput.addEventListener('keydown', function(e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            handleSubmit(e);
        }
    });

    checkMeshStatus();
    setInterval(checkMeshStatus, 30000);

    async function handleSubmit(e) {
        e.preventDefault();
        const message = messageInput.value.trim();
        if (!message) return;

        addMessage(message, 'user');
        messageInput.value = '';
        sendButton.disabled = true;

        showTypingIndicator();

        try {
            const response = await fetch('/api/chat', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ message })
            });

            const data = await response.json();
            removeTypingIndicator();

            if (data.error) {
                addMessage('Sorry, something went wrong. Please try again.', 'bot');
                return;
            }

            addMessage(data.response, 'bot', data.mode === 'crisis');
            updateModeIndicator(data.mode, data.risk_level);
            
            if (data.node_analysis) {
                updateNodeAnalysis(data.node_analysis);
            }

            if (data.show_crisis_resources) {
                showCrisisResources(data.hotlines);
            } else {
                hideCrisisResources();
            }

        } catch (error) {
            removeTypingIndicator();
            addMessage('Connection error. Please check your internet and try again.', 'bot');
            console.error('Chat error:', error);
        } finally {
            sendButton.disabled = false;
            messageInput.focus();
        }
    }

    function addMessage(text, type, isCrisis = false) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${type}-message${isCrisis ? ' crisis-message' : ''}`;
        
        const avatar = type === 'bot' ? '🤗' : '👤';
        const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

        const formattedText = text
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\n/g, '<br>');

        messageDiv.innerHTML = `
            <div class="message-avatar">${avatar}</div>
            <div class="message-content">
                <p>${formattedText}</p>
                <span class="message-time">${time}</span>
            </div>
        `;

        chatMessages.appendChild(messageDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    function showTypingIndicator() {
        const typingDiv = document.createElement('div');
        typingDiv.className = 'message bot-message';
        typingDiv.id = 'typingIndicator';
        typingDiv.innerHTML = `
            <div class="message-avatar">🤗</div>
            <div class="typing-indicator">
                <div class="typing-dot"></div>
                <div class="typing-dot"></div>
                <div class="typing-dot"></div>
            </div>
        `;
        chatMessages.appendChild(typingDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    function removeTypingIndicator() {
        const indicator = document.getElementById('typingIndicator');
        if (indicator) indicator.remove();
    }

    function updateModeIndicator(mode, riskLevel) {
        let badge = '';
        if (mode === 'crisis') {
            badge = '<span class="mode-badge crisis">Crisis Mode - Please Seek Help</span>';
        } else if (riskLevel === 'high' || riskLevel === 'medium') {
            badge = `<span class="mode-badge support">Support Mode - ${riskLevel} concern</span>`;
        } else {
            badge = '<span class="mode-badge support">Support Mode</span>';
        }
        modeIndicator.innerHTML = badge;
    }

    function updateNodeAnalysis(nodes) {
        if (!nodes || nodes.length === 0) {
            nodeList.innerHTML = '<p class="placeholder">No analysis available</p>';
            return;
        }

        nodeList.innerHTML = nodes.map(node => {
            const healthClass = node.is_healthy ? 'healthy' : 'unhealthy';
            const riskClass = getRiskClass(node.risk_contribution);
            
            return `
                <div class="node-item ${healthClass}">
                    <div class="node-name">${node.name}</div>
                    <div class="node-details">${node.details || 'Processing...'}</div>
                    <span class="node-risk ${riskClass}">
                        Risk: ${(node.risk_contribution * 100).toFixed(0)}%
                    </span>
                </div>
            `;
        }).join('');
    }

    function getRiskClass(risk) {
        if (risk >= 0.6) return 'risk-high';
        if (risk >= 0.3) return 'risk-medium';
        return 'risk-low';
    }

    function showCrisisResources(hotlines) {
        crisisResources.style.display = 'block';
        if (hotlines) {
            const list = Object.entries(hotlines)
                .map(([country, number]) => `<li><strong>${country}:</strong> ${number}</li>`)
                .join('');
            crisisResources.querySelector('ul').innerHTML = list;
        }
    }

    function hideCrisisResources() {
        crisisResources.style.display = 'none';
    }

    async function checkMeshStatus() {
        try {
            const response = await fetch('/api/mesh/status');
            const status = await response.json();
            
            const statusDot = meshStatus.querySelector('.status-dot');
            const statusText = meshStatus.querySelector('.status-text');
            
            if (status.mesh_operational) {
                statusDot.style.background = '#10b981';
                statusText.textContent = `${status.healthy_nodes}/${status.total_nodes} nodes active`;
            } else {
                statusDot.style.background = '#ef4444';
                statusText.textContent = 'System degraded';
            }
        } catch (error) {
            console.error('Failed to check mesh status:', error);
        }
    }
});

function dismissDisclaimer() {
    document.getElementById('disclaimerBanner').style.display = 'none';
}

async function getTechnique(type) {
    try {
        const response = await fetch(`/api/technique/${type}`);
        const technique = await response.json();
        
        const chatMessages = document.getElementById('chatMessages');
        const messageDiv = document.createElement('div');
        messageDiv.className = 'message bot-message';
        
        const formattedDesc = technique.description
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\n/g, '<br>');
        
        messageDiv.innerHTML = `
            <div class="message-avatar">🧘</div>
            <div class="message-content">
                <p><strong>${technique.name}</strong><br><br>${formattedDesc}</p>
                <span class="message-time">${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
            </div>
        `;
        
        chatMessages.appendChild(messageDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    } catch (error) {
        console.error('Failed to get technique:', error);
    }
}
